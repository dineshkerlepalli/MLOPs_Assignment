# You can create more variables according to your project. The following are the basic variables that have been provided to you
DB_PATH = '/home/Assignment/01_data_pipeline/scripts'
DB_FILE_NAME = 'utils_output.db'
UNIT_TEST_DB_FILE_NAME = 'unit_test_cases.db'
DATA_DIRECTORY = '/home/Assignment/01_data_pipeline/scripts'
INTERACTION_MAPPING = 'interaction_mapping.csv'
