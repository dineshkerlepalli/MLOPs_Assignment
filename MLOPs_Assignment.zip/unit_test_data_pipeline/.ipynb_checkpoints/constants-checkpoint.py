# You can create more variables according to your project. The following are the basic variables that have been provided to you
DB_PATH = ''
DB_FILE_NAME = 'utils_output.db'
UNIT_TEST_DB_FILE_NAME = 'unit_test_cases.db'
DATA_DIRECTORY = ''
INTERACTION_MAPPING = 'interaction_mapping.csv'
#INDEX_COLUMNS = 
#NOT_FEATURES = 

